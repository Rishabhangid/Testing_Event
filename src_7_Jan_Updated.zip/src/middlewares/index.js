module.exports.Authorization = require('./authorization');
module.exports.Authentication = require('./auth');
module.exports.checkEmailAndPhone = require('./checkEmailAndPhone.js');
